export class Notification{

    isSuccess : boolean = false;
    message : string; 
    }