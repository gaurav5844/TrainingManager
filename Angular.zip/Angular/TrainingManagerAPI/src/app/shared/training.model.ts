export class Training {
     id: number;
     name: string;
     startDate: Date;
     endDate: Date;
}
