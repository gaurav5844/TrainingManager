import { Injectable } from '@angular/core';
import { Training } from './training.model';
import { HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class TrainingService {

  // Data Array
  data = [];
  formData: Training = new Training();

  constructor(private http : HttpClient) { }
  listData = [];

  // Function to post data to back end
  postData(formData : Training) {
               return  this.http.post(
          'http://localhost:61301/Api/ManageTrainings',
          formData);                 
  }
  
// Function to get data from back end
  getData(){
         this.http.get('http://localhost:61301/Api/ManageTrainings')
        .subscribe(
         response => {
            if(response != null){
               this.listData = response as [];
            }
          }         
        );  
  }
}
