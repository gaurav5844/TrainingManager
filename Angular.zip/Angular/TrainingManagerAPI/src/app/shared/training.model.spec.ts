import { Training } from './training.model';

describe('Training', () => {
  it('should create an instance', () => {
    expect(new Training()).toBeTruthy();
  });
});
