import { Component, OnInit, ViewChild } from '@angular/core';
import { TrainingService } from 'src/app/shared/training.service';
import { NgForm } from '@angular/forms';
import { Notification } from '../../shared/notification';

@Component({
  selector: 'app-training',
  templateUrl: './training.component.html',
  styleUrls: []
})
export class TrainingComponent implements OnInit {

  // This is used to refer template form
  @ViewChild('form', { 'static': false }) form: NgForm;

  // Property to display in html file to show custom error
  error: any = { isError: false, errorMessage: '' };

  // External service to handle notification
  notification: Notification = new Notification();

  constructor(private service: TrainingService) { }

  ngOnInit() {
  }

  onSubmit(form: NgForm) {
    this.compareTwoDates();
    // Data call
    this.service.postData(form.value)
    .subscribe(
      response => {
        if(response != null){
          this.service.getData();
           this.notification.isSuccess = true;
           this.notification.message = "Successfully Saved!";
           // To display success message for 5 seconds only
          setTimeout(() => {
          this.notification.message = '';
          } , 5000);
        }
      },
      error => {}
    ); 
 }

  // Function to handle start date and end date validator
  compareTwoDates() {
    if ((new Date(this.form.controls['startDate'].value)).getTime() 
        >
        (new Date(this.form.controls['endDate'].value)).getTime()
        ||
        (new Date(this.form.controls['startDate'].value)).getTime() 
        ==
        (new Date(this.form.controls['endDate'].value)).getTime()
        
        ) {
      // Setting property in case of error
      this.error = { isError: true, errorMessage: 'End Date must be greater then start date' };

      // Setting the Error property for form element endDate to make it invalid
      this.form.controls['endDate'].setErrors({ 'noMatch': true });
    }
  }
}
