import { Component, OnInit } from '@angular/core';
import { TrainingService } from '../shared/training.service';

@Component({
  selector: 'app-trainings',
  templateUrl: './trainings.component.html',
  styleUrls: []
})
export class TrainingsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
