import { Component, OnInit } from '@angular/core';
import { TrainingService } from 'src/app/shared/training.service';
import { Training } from 'src/app/shared/training.model';

@Component({
  selector: 'app-training-list',
  templateUrl: './training-list.component.html',
  styleUrls: []
})
export class TrainingListComponent implements OnInit {
    constructor(private service: TrainingService) { }

  ngOnInit() {
    // Calling getData API using Service and assigning in local property
    this.service.getData();
  }
}
