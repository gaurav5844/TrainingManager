import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TrainingsComponent } from './trainings.component';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { TrainingComponent } from './training/training.component';
import { FormsModule } from '@angular/forms';

describe('TrainingsComponent', () => {
  let component: TrainingsComponent;
  let fixture: ComponentFixture<TrainingsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TrainingsComponent ,
      TrainingComponent],
      imports: [
        FormsModule
      ],
      schemas:[
        CUSTOM_ELEMENTS_SCHEMA
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TrainingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
